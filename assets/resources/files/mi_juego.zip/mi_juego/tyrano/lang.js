window.tyrano_lang = {
  word: {
    go_title: "¿Volver a la pantalla de título?",
    exit_game: "¿Cerrar la ventana y salir del juego?",
    not_saved: "Ranura de guardado vacía",
    tag: "Nombre de etiqueta",
    not_exists: "no se ha podido encontrar",
    error: "Se ha producido un error. Compruebe el script del escenario.",
    label: "La etiqueta",
    label_double: "tiene más de una aparición en el archivo de escena",
    error_occurred: "Se ha producido un error. Compruebe el script del escenario.",
    save_file_violation_1:
      "Guarda quita los datos detectados. Cargue datos sólo de una fuente de confianza.",
    save_file_violation_2: "¿Cargar los datos guardados e iniciar el juego?",
    save_file_violation_3:
      "Arranque abortado. Por favor, borre los datos guardados y reinicie.",
    reload: "Recargar",
  },

  novel: {
    file_menu_button_save: "menu_button_save.gif",
    file_menu_button_load: "menu_button_load.gif",
    file_menu_button_message_close: "menu_message_close.gif",
    file_menu_button_skip: "menu_button_skip.gif",
    file_menu_button_title: "menu_button_title.gif",
    file_menu_button_close: "menu_button_close.png",
    file_menu_bg: "menu_bg.jpg",
    file_save_bg: "menu_save_bg.jpg",
    file_load_bg: "menu_load_bg.jpg",
    file_button_menu: "button_menu.png",
  },
};
